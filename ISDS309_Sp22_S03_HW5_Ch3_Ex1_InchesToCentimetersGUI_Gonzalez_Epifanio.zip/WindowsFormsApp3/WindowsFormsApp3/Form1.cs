﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Assignment#5 - Chapter #3 - Exercise #1  (Ex: Assign 5 - Ch 3 - Ex 1)
            // Program: InchestoCentimetersGUI
            // Author: Epifanio Gonzalez
            // Date: 4/10/22
            // Description: Changing inches to centimeters

            double inches, centimeters;

            inches = int.Parse(textBox1.Text);
            centimeters = inches * 2.54;

            label2.Text = "Your number in centimeters is " + centimeters;

        }
    }
}
